module FooHelper
  def baz() end
end
